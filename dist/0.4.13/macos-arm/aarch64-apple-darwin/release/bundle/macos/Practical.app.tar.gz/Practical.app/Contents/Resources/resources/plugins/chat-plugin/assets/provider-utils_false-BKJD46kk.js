throw new Error('Could not resolve "@valibot/to-json-schema" imported by "@ai-sdk/provider-utils".');
